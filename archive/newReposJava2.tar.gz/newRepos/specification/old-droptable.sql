drop table Document;
drop table DTDName;
drop table SchemaName;
drop table DocumentName;
drop table Language;
drop table Country;
drop table Status;
drop table AuthorInstance;
drop table Author;
drop table Element;
drop table NameSpace;
drop table ElementInstance;
drop table ElementChildInstance;
drop table Word;
drop table Whitespace;
drop table Attribute;



