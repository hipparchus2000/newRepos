package com.chrystal.nr;

public class nrPropertyName extends StandardIndirectName{
    String getTableName() {
	return ("PropertyName");
    };
};
