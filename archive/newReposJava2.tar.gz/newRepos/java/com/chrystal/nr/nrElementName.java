package com.chrystal.nr;

public class nrElementName extends StandardIndirectName{
    String getTableName() {
	return ("ElementName");
    };
};
