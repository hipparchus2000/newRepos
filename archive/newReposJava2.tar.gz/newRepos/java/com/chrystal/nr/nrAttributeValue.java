package com.chrystal.nr;

public class nrAttributeValue extends StandardIndirectData{
    String getTableName() {
	return ("AttributeValue");
    };
};
