package com.chrystal.nr;
import java.util.*;
import java.sql.*;

public class DataStore{

    public String NormalizeString(String ins) {
	char ch;
	String outs="";
	String chs="";
	
	for (int i=0;i<ins.length();i++) {
	   ch=ins.charAt(i);
	   if (ch==' ') {
	   	chs="&nbsp;";
	   } else if (ch==8) {
	   	chs="&tab;";
	   } else if (ch=='\r') {
	   	chs="&cr;";
	   } else if (ch=='\n') {
	        chs="&lf;";
	   } else if (ch=='&') {
	        chs="&amp;";
	   } else {
	     chs=String.valueOf(ch);
	   };

	   outs+=chs;
	};   

	return outs;

    };


    public String DeNormalizeString(String ins) {

        //this function will only be used for export from the db.
	//it is not used for lookup etc.

	//find &nbsp and replace with ' '
	//find &tab; and replace with char8
	//find &nl; and replace with \n
	//find &cr; and replace with \r
	//find &amp; and replace with &
	String outs=ins;

	String nbsp="&nbsp;";
	String tab="&tab;";
	String cr="&cr;";
	String lf="&lf;";
	String amp="&amp;";
	
	int nbsp_pos=0;
	int tab_pos=0;
	int cr_pos=0;
	int lf_pos=0;
	int amp_pos=0;

	String strBefore="";
	String strAfter="";

	boolean continue_replace=true;
	
	while (continue_replace) {
	  nbsp_pos=outs.indexOf(nbsp);
	  if (nbsp_pos>0) {
            strBefore=outs.substring(0,nbsp_pos);
	    strAfter=outs.substring(nbsp_pos+nbsp.length());
	    outs=strBefore+" "+strAfter;
	    continue_replace=true;
	  };

 	  tab_pos=outs.indexOf(tab);
	  if (tab_pos>0) {
            strBefore=outs.substring(0,tab_pos);
	    strAfter=outs.substring(tab_pos+tab.length());
	    outs=strBefore+" "+strAfter;
	    continue_replace=true;
	  };

	  cr_pos=outs.indexOf(cr);
	  if (cr_pos>0) {
            strBefore=outs.substring(0,cr_pos);
	    strAfter=outs.substring(cr_pos+cr.length());
	    outs=strBefore+" "+strAfter;
	    continue_replace=true;
	  };
	  
	  lf_pos=outs.indexOf(lf);
	  if (lf_pos>0) {
            strBefore=outs.substring(0,lf_pos);
	    strAfter=outs.substring(lf_pos+lf.length());
	    outs=strBefore+" "+strAfter;
	    continue_replace=true;
	  };

	  amp_pos=outs.indexOf(amp);
	  if (amp_pos>0) {
            strBefore=outs.substring(0,amp_pos);
	    strAfter=outs.substring(amp_pos+amp.length());
	    outs=strBefore+" "+strAfter;
	    continue_replace=true;
	  };


	  
        };

	

	
	return ins;
    
    };

    public int store( String DataValue,
		      String TableName,
		      String DataFieldName) 
    {
	DataValue=NormalizeString(DataValue);
	
	Connection conn;
	PreparedStatement st;
	ResultSet rs;

	int id=0;

	try {
	    //String driverName="sun.jdbc.odbc.JdbcOdbcDriver";
	    String driverName="org.gjt.mm.mysql.Driver";
	    //load driver -driverName
	    try {
		Class.forName(driverName).newInstance();
	    } catch (java.lang.ClassNotFoundException ex) {
	    	System.out.println("Class Not Found for odbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.InstantiationException ex) {
	    	System.out.println("jdbc driver Instantiation failed");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.IllegalAccessException ex) {
	    	System.out.println("IllegalAccess Exception when trying to instantiate jdbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    };


	    //Open connection -url -username -password
	    //String url="jdbc:odbc:test";
	    String url="jdbc:mysql://localhost:3306/test";
	    String username="x";
	    String password="x";
	    conn=DriverManager.getConnection(url);//,username,password);

	    //create statement SELECT id from tablename order by (id * -1)
	    String sql_command="SELECT id FROM "+TableName+" ORDER BY (id * -1);";
 	    System.out.println(sql_command);
	    st=conn.prepareStatement(sql_command);
	    
	    //execute statement
	    rs=st.executeQuery();

	    try {
		//find first record of result set
		rs.next();

		//retrieve number
		id=rs.getInt(1);

		//(0) by default - this will be run once at least
		//close connection
		conn.close();
	    } catch (java.lang.NullPointerException ex) {
		//ignore this, it just means there are no records
		System.out.println("ignore this it means no records but NullPointerException");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
	    } catch (Exception ex) {
		//ignore this too
		System.out.println("ignore this Exception it means no records??");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
	    };

	    //increment id
	    id++;
	    
	    //convert id to string
	    Integer idInteger=new Integer(id);
	    String idString=idInteger.toString();

	    System.out.println("preparing to insert a new line into a table");
	    //open connection
	    Connection conn1;
	    conn1=DriverManager.getConnection(url);

	    //create statement INSERT INTO tablename (id,<data|name>) VALUES (id,<data|name>
	    sql_command="INSERT INTO "+TableName+" (id,"+DataFieldName+") VALUES ("+idString+",'"+DataValue+"');";
	    System.out.println(sql_command);
	    st=conn1.prepareStatement(sql_command);
	    
	    //execute statement
	    st.execute();
	    
	    //close connection
	    conn1.close();

	} catch (SQLException ex) {
		System.out.println("SQLException on Inserting row into table");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
	        return -1;
	};

	return id;
    };

    public int lookup(	  String DataValue,
			  String TableName,
			  String DataFieldName) 
    {
	DataValue=NormalizeString(DataValue);
	
	if (DataValue.compareTo("")==0) {
		return 0;
	};
	Connection conn;
	PreparedStatement st;
	ResultSet rs;
	boolean found=false;
	int id=-1;

	try {
 	    //String driverName="sun.jdbc.odbc.JdbcOdbcDriver";
	    String driverName="org.gjt.mm.mysql.Driver";
	    //load driver -driverName
	    try {
		Class.forName(driverName).newInstance();
	    } catch (java.lang.ClassNotFoundException ex) {
	    	System.out.println("Class Not Found for odbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.InstantiationException ex) {
	    	System.out.println("jdbc driver Instantiation failed");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.IllegalAccessException ex) {
	    	System.out.println("IllegalAccess Exception when trying to instantiate jdbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    };

   
	    //Open connection -url -username -password
	    //String url="jdbc:odbc:test";
	    String url="jdbc:mysql://localhost:3306/test";
	    String username="x";
	    String password="x";
	    conn=DriverManager.getConnection(url);//,username,password);

	    //create statement SELECT id from tablename where <datafieldname> like '<datafieldvalue>'
	    String sql_command="SELECT id FROM "+TableName+" WHERE ("+DataFieldName+" LIKE '"+DataValue+"');";
	    System.out.println(sql_command);
	    st=conn.prepareStatement(sql_command);
	    
	    //execute statement
	    rs=st.executeQuery();

	    //find first record of result set
	    rs.next();
	    
	    //retrieve number
	    id=rs.getInt(1);
	    
	    //(0) by default - this will be run once at least
	    //close connection
	    conn.close();
	    
	} catch (Exception e) {
		System.out.println("Exception when selecting records from database (looking up)");
	    	System.out.println(e.toString());
		e.printStackTrace(System.out);
	        id=-1;
	};
	
	return id;

    };


    //4 int types:

    public int store(	 int DataValue0,
			 int DataValue1,
			 int DataValue2,
			 String TableName,
			 String DataFieldName0,
			 String DataFieldName1,
			 String DataFieldName2) 
    {

	Connection conn;
	PreparedStatement st;
	ResultSet rs;

	int id=0;

	try {
	    //String driverName="sun.jdbc.odbc.JdbcOdbcDriver";
	    String driverName="org.gjt.mm.mysql.Driver";
	    //load driver -driverName
	    try {
		Class.forName(driverName).newInstance();
	    } catch (java.lang.ClassNotFoundException ex) {
	    	System.out.println("Class Not Found for odbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.InstantiationException ex) {
	    	System.out.println("jdbc driver Instantiation failed");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.IllegalAccessException ex) {
	    	System.out.println("IllegalAccess Exception when trying to instantiate jdbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    };

    	    //Open connection -url -username -password
	    //String url="jdbc:odbc:test";
	    String url="jdbc:mysql://localhost:3306/test";
	    String username="x";
	    String password="x";
	    conn=DriverManager.getConnection(url);//,username,password);

	    //create statement SELECT id from tablename order by id descending
	    String sql_command="SELECT id FROM "+TableName+" ORDER BY (id * -1);";
	    System.out.println(sql_command);
	    st=conn.prepareStatement(sql_command);
	    
	    //execute statement
	    rs=st.executeQuery();

	    try {
		//find first record of result set
		rs.next();
	    
		//retrieve number
		id=rs.getInt(1);

	    } catch (java.lang.NullPointerException ex) {
	    	System.out.println("nullPointer exception - no data yet?");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		//no data yet
	    } catch (Exception ex) {
	    	System.out.println("Exception on selecting record to get id for next record ");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		//same?
	    };

	    //(0) by default - this will be run once at least
	    //close connection
	    conn.close();

	    //increment id
	    id++;
	    
	    //convert id to string
	    Integer idInteger=new Integer(id);
	    String idString=idInteger.toString();

	    //convert int data values to strings
	    Integer d0=new Integer(DataValue0);
	    Integer d1=new Integer(DataValue1);
	    Integer d2=new Integer(DataValue2);
	    String sd0=d0.toString();
	    String sd1=d1.toString();
	    String sd2=d2.toString();


	    System.out.println("preparing to insert a line into a table (2)");
	    //open connection
	    Connection conn1;
	    conn1=DriverManager.getConnection(url);

	    //create statement INSERT INTO tablename (id,<data|name>) VALUES (id,<data|name>
	    sql_command="INSERT INTO "+TableName+" (id,"+DataFieldName0+","+DataFieldName1+","+DataFieldName2+
		") VALUES ("+idString+","+sd0+","+sd1+","+sd2+");";
	    System.out.println(sql_command);
	    st=conn1.prepareStatement(sql_command);
	    
	    //execute statement
	    st.execute();
	    
	    //close connection
	    conn1.close();

	} catch (SQLException ex) {
		System.out.println("SQLException on trying to INSERT a row");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
	        return -1;
	};

	return id;
    };

    public int lookup(int DataValue0,
			  int DataValue1,
			  int DataValue2,
			  String TableName,
			  String DataFieldName0,
			  String DataFieldName1,
			  String DataFieldName2) 
    {
	Connection conn;
	PreparedStatement st;
	ResultSet rs;
	int id=-1;

	try {
 	    //String driverName="sun.jdbc.odbc.JdbcOdbcDriver";
	    String driverName="org.gjt.mm.mysql.Driver";
	    //load driver -driverName
	    try {
		Class.forName(driverName).newInstance();
	    } catch (java.lang.ClassNotFoundException ex) {
	    	System.out.println("Class Not Found for odbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.InstantiationException ex) {
	    	System.out.println("jdbc driver Instantiation failed");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    } catch (java.lang.IllegalAccessException ex) {
	    	System.out.println("IllegalAccess Exception when trying to instantiate jdbc driver");
	    	System.out.println(ex.toString());
		ex.printStackTrace(System.out);
		return -1;
	    };

   
	    //Open connection -url -username -password
	    //String url="jdbc:odbc:test";
	    String url="jdbc:mysql://localhost:3306/test";
	    String username="x";
	    String password="x";
	    conn=DriverManager.getConnection(url);//,username,password);

	    //convert int data values to strings
	    Integer d0=new Integer(DataValue0);
	    Integer d1=new Integer(DataValue1);
	    Integer d2=new Integer(DataValue2);
	    String sd0=d0.toString();
	    String sd1=d1.toString();
	    String sd2=d2.toString();

	    //create statement SELECT id from tablename where <datafieldname> like '<datafieldvalue>'
	    String sql_command="SELECT id FROM "+TableName+" WHERE (("+DataFieldName0+"="+sd0+") AND ("+
		DataFieldName1+"="+sd1+") AND ("+DataFieldName2+"="+sd2+"));";
     	    System.out.println(sql_command);
	    st=conn.prepareStatement(sql_command);
	    
	    //execute statement
	    rs=st.executeQuery();

	    //find first record of result set
	    rs.next();

	    //retrieve number
	    id=rs.getInt(1);

	    //(0) by default - this will be run once at least
	    //close connection
	    conn.close();
	} catch (Exception e) {
		System.out.println("Exception on looking up a record ");
		System.out.println(e.toString());
		e.printStackTrace(System.out);
	    id=-1;
	};

	return id;

    };


};









