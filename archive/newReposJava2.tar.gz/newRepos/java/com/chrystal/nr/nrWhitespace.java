package com.chrystal.nr;

public class nrWhitespace extends StandardIndirectData{
    String getTableName() {
	return ("Whitespace");
    };
};
