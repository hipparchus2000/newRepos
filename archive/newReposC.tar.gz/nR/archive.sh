#!/bin/sh
cp ./nR.c ./archive/nR.c/`date +%y%m%d%H%M%S`
ls ./archive/nR.c

