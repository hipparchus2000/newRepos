#!/bin/sh
cc -wa -o nR nR.c
