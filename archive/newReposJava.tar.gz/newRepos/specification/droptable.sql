drop table DocumentInstance;
drop table PropertyInstance;
drop table PropertyName;
drop table PropertyValue
drop table ElementInstance;
drop table ElementName;
drop table ElementChildInstance;
drop table NameSpace;
drop table Word;
drop table Whitespace;
drop table AttributeInstance;
drop table AttributeName;
drop table AttributeValue;


