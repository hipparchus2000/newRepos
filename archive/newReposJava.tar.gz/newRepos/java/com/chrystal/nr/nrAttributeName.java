package com.chrystal.nr;

public class nrAttributeName extends StandardIndirectName{
    String getTableName() {
	return ("AttributeName");
    };
};
