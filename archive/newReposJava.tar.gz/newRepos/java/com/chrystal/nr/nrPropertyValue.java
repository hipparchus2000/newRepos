package com.chrystal.nr;

public class nrPropertyValue extends StandardIndirectData{
    String getTableName() {
	return ("PropertyValue");
    };
};
