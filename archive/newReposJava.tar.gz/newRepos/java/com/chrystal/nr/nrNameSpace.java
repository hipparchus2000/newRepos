package com.chrystal.nr;

public class nrNameSpace extends StandardIndirectData{
    String getTableName() {
	return ("NameSpace");
    };
};
