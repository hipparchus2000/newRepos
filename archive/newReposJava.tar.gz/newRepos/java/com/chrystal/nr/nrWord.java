package com.chrystal.nr;

public class nrWord extends StandardIndirectData{
    String getTableName() {
	return ("Word");
    };
};
