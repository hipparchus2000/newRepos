//This software is licensed under the Gnu Public Licence (GPL)
//see www.gnu.org for more information. Jeff Davies (c) 2002.

package org.piranha.nr;

abstract public class StandardLookupType{
    int id;
    boolean newlyMade=false;
    boolean error=false;

    abstract String getDataFieldName();
    abstract String getTableName();
    abstract String getDataValue();
    abstract void setDataValue(String dat);

    public int getID() {
	return id;
    };

    public void setID(int newID) {
	id =newID;
    };


    /**returns true if stored successfully
     */
    public boolean store() {
	DataStore datastore=new DataStore();
	id=datastore.store(getDataValue(),getTableName(),getDataFieldName());
	
	//returns success if not -1 otherwise failure
	return (id!=-1);
    };

    /** returns true if found  
     */
    public boolean lookup() {
	DataStore datastore=new DataStore();
	id=datastore.lookup(getDataValue(),getTableName(),getDataFieldName());
	
	System.out.print("StandardLookupType found item ");
	System.out.println(id);
	
	//return success if not -1 otherwise failure
	return (id!=-1);
    };

    public void findOrStore() {
	if (lookup()==false) {
	    error=!store();
	    newlyMade=true;
	};
    }

};



