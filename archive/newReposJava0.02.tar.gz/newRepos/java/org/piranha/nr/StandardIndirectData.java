//This software is licensed under the Gnu Public Licence (GPL)
//see www.gnu.org for more information. Jeff Davies (c) 2002.

package org.piranha.nr;

abstract public class StandardIndirectData extends StandardLookupType{
    String data;
  
    String getDataFieldName() {
	return ("data");
    };

    void setDataValue(String dat) {
	data=dat;
    };

    String getDataValue() {
	return (data);
    };

};

