//This software is licensed under the Gnu Public Licence (GPL)
//see www.gnu.org for more information. Jeff Davies (c) 2002.

package org.piranha.nr;

public class nrAttributeValue extends StandardIndirectData{
    String getTableName() {
	return ("AttributeValue");
    };
};

