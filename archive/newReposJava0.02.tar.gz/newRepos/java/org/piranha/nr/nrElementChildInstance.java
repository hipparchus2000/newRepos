//This software is licensed under the Gnu Public Licence (GPL)
//see www.gnu.org for more information. Jeff Davies (c) 2002.

package org.piranha.nr;

public class nrElementChildInstance extends Standard6intType {

    int parentElementInstanceID; //
    int childSequenceNum;
    int childType; //this differentiates between child type elementInstance, AttributeInstance, Word(Instance), Whitespace (Instance)
    int childURIInstanceID; //this is the ID of the  in the relevant table (be it elementInstance, AttributeInstance etc.
    int childNameInstanceID;
    int childValueInstanceID;

    String getDataFieldName0() {
	return("elementInstanceID") ;
    };

    String getDataFieldName1() {
	return("childSequenceNum");
    };

    String getDataFieldName2() {
	return("childType");
    };

   String getDataFieldName3() {
       return("childURIInstanceID");
   };

   String getDataFieldName4() {
      return ("childNameInstanceID");
   };

   String getDataFieldName5() {
      return ("childValueInstanceID");
   };
      

   
    String getTableName() {
	return("ElementChildInstance");
    };

    int getDataValue0() {
	return parentElementInstanceID;
    };

    int getDataValue1() {
	return childSequenceNum;
    };

    int getDataValue2() {
	return childType;
    };

    int getDataValue3() {
        return childURIInstanceID;
    };

    int getDataValue4() {
       return childNameInstanceID;
    };
    
    int getDataValue5() {
       return childValueInstanceID;
    };


    void setDataValue0(int dat) {
	parentElementInstanceID=dat;
    };

    void setDataValue1(int dat) {
	childSequenceNum=dat;
    };

    void setDataValue2(int dat) {
	childType=dat;
    };
    void setDataValue3(int dat) {
	childURIInstanceID=dat;
    };
    void setDataValue4(int dat) {
	childNameInstanceID=dat;
    };
    void setDataValue5(int dat) {
	childValueInstanceID=dat;
    };


};

