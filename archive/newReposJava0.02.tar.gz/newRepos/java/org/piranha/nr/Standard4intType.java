//This software is licensed under the Gnu Public Licence (GPL)
//see www.gnu.org for more information. Jeff Davies (c) 2002.

package org.piranha.nr;

abstract public class Standard4intType{

    int id;

    boolean newlyMade=false;
    boolean error=false;

    abstract String getDataFieldName0();
    abstract String getDataFieldName1();
    abstract String getDataFieldName2();

    abstract String getTableName();

    abstract int getDataValue0();
    abstract void setDataValue0(int dat);
    abstract int getDataValue1();
    abstract void setDataValue1(int dat);
    abstract int getDataValue2();
    abstract void setDataValue2(int dat);

    public int getID() {
	return id;
    };

    public void setID(int newID) {
	id=newID;
    };


    /**returns true if stored successfully
     */
    public boolean store() {
	DataStore datastore=new DataStore();
	int thisid=datastore.store(getDataValue0(),
					getDataValue1(),
					getDataValue2(),
					getTableName(),
					getDataFieldName0(),
					getDataFieldName1(),
					getDataFieldName2());
	setID(thisid);
	return (thisid!=-1);
    };

    /** returns true if found  
     */
    public boolean lookup() {
	DataStore datastore=new DataStore();
	int thisid=datastore.lookup(getDataValue0(),
				       getDataValue1(),
				       getDataValue2(),
				       getTableName(),
				       getDataFieldName0(),
				       getDataFieldName1(),
				       getDataFieldName2());
	setID(thisid);
	return (thisid!=-1);
    };

    public void findOrStore() {
	if (lookup()==false) {
	    error=!store();
	    newlyMade=true;
	};
    }

};





