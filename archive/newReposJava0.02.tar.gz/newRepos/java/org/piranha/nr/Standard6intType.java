//This software is licensed under the Gnu Public Licence (GPL)
//see www.gnu.org for more information. Jeff Davies (c) 2002.

package org.piranha.nr;

abstract public class Standard6intType{

    boolean newlyMade=false;
    boolean error=false;

    abstract String getDataFieldName0();
    abstract String getDataFieldName1();
    abstract String getDataFieldName2();
    abstract String getDataFieldName3();
    abstract String getDataFieldName4();
    abstract String getDataFieldName5();

    abstract String getTableName();

    abstract int getDataValue0();
    abstract void setDataValue0(int dat);
    abstract int getDataValue1();
    abstract void setDataValue1(int dat);
    abstract int getDataValue2();
    abstract void setDataValue2(int dat);
    abstract int getDataValue3();
    abstract void setDataValue3(int dat);
    abstract int getDataValue4();
    abstract void setDataValue4(int dat);
    abstract int getDataValue5();
    abstract void setDataValue5(int dat);

    //note this class is only used by the element child instance. This record is only ever written as part of
    //
    public boolean store() {
	DataStore datastore=new DataStore();
	return datastore.store(getDataValue0(),
			getDataValue1(),
			getDataValue2(),
			getDataValue3(),
			getDataValue4(),
			getDataValue5(),
			getTableName(),
			getDataFieldName0(),
			getDataFieldName1(),
			getDataFieldName2(),
			getDataFieldName3(),
			getDataFieldName4(),
			getDataFieldName5());
	
    };

    public boolean lookup() {
       DataStore datastore=new DataStore();
       return datastore.lookup(getDataValue0(),
			       getDataValue1(),
			       getDataValue2(),
			       getDataValue3(),
			       getDataValue4(),
			       getDataValue5(),
			       getTableName(),
			       getDataFieldName0(),
			       getDataFieldName1(),
			       getDataFieldName2(),
			       getDataFieldName3(),
			       getDataFieldName4(),
			       getDataFieldName5());
   };
	
   public void findOrStore() {
      if (lookup()==false) {
         store();
      };
   };


};





