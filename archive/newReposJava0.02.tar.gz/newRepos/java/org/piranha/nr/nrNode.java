//This software is licensed under the Gnu Public Licence (GPL)
//see www.gnu.org for more information. Jeff Davies (c) 2002.

package org.piranha.nr;

import java.util.*;

public class nrNode {

    public final static int TypeAttributeInstance=0;
    public final static int TypeElementInstance=1;
    public final static int TypeWhitespace=2;
    public final static int TypeWord=3;

    private int nodeTypeID=-1;
    private int uriID=-1;
    private int nameID=-1;
    private int valueID=-1;
    public int ID; //this is the element instance ID and is only used
    //for nodes that are associated with element instances. 

    private int checksum=-1;

    public int getChecksum() {
 	int cksum=nodeTypeID+uriID+nameID+valueID;
	nrNode curNode;
	for (int nodeNum=0;nodeNum<children.size();nodeNum++) {
	  curNode=(nrNode)children.get(nodeNum);
   	  if (curNode.nodeTypeID==TypeElementInstance) {
	    cksum+=curNode.getChecksum();
	  };
	}; 

	return cksum;
    };

    public void writeChildRows() {
        nrNode curNode;
	for (int nodeNum=0;nodeNum<children.size();nodeNum++) {
	  curNode=(nrNode)children.get(nodeNum);
	  
	  //output this node to sql table fetch id for use by children
	  nrElementChildInstance c=new nrElementChildInstance();
	  c.parentElementInstanceID=curNode.parent.ID;
	  c.childSequenceNum=nodeNum;
	  c.childType=curNode.nodeTypeID;
	  c.childURIInstanceID=curNode.uriID;
	  c.childNameInstanceID=curNode.nameID;
	  c.childValueInstanceID=curNode.valueID;
	  c.findOrStore();
	     
	  if (curNode.nodeTypeID==TypeElementInstance) {
	      //output the children of this node
	      curNode.writeChildRows();
	  };


	}; //end for

    };


    //always set, so you know what this is in the tree
    public void setNodeTypeID(int id) {
	nodeTypeID=id;
    };

    //set for attributes and elements
    public void setUriID(int id) {
	uriID=id;
    };
	
    //set for attributes and elements
    public void setNameID(int id) {
	nameID=id;
    };

    //set for attributes, words and whitespace
    public void setValueID(int id) {
	valueID=id;
    };


    //always set, so you know what this is in the tree
    public int getNodeTypeID() {
	return nodeTypeID;
    };

    //set for attributes and elements
    public int getUriID() {
	return uriID;
    };
	
    //set for attributes and elements
    public int getNameID() {
	return nameID;
    };

    //set for attributes, words and whitespace
    public int getValueID() {
	return valueID;
    };

    public Vector children=new Vector(); //they are nrNodes
    public nrNode parent=null;

}









